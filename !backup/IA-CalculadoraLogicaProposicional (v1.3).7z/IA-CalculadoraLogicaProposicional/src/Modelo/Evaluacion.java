/*
    1. Separar proposicion por postfijo
    2. Evaluar
    a. Caso 1: primeras 2 variables y primer operador, agregar resultado a arrFinal
    b. Caso 2: resultado de la primera evaluación, siguiente variable y siguiente operador, agregar resultado
        a arrFinal
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author rms
 */
public class Evaluacion extends Valores {

    public static ArrayList<ArrayList> arrayTabla = new ArrayList<>();

    /**
    Método para iniciar la evaluación, convierte una cadena con la proposición en postfijo,
    después se manda cada caracter a un ArrayList, y las variables se sustituyen por ArrayLists
    @param proposicion 
     */
    public static void evaluacionIniciar(String proposicion) {
        arrayTabla.clear();
        String aux = Postfijo.convertiraPostfijo(proposicion);

        ArrayList<Object> prop = new ArrayList<>();
        for (int i = 0; i < aux.length(); i++) {
            prop.add(aux.charAt(i));
        }
//        System.out.println(prop);

        for (int i = 0; i < prop.size(); i++) {
            char c = (char) prop.get(i);
            if (!(prop.get(i).equals('y') || prop.get(i).equals('o') || prop.get(i).equals('f')
                    || prop.get(i).equals('b') || prop.get(i).equals('-'))) {
                switch (c) {
                    case 'P':
                        prop.set(i, Valores.vectorVariables[0]);
                        arrayTabla.add((ArrayList<Character>) Valores.vectorVariables[0]);
                        break;
                    case 'Q':
                        prop.set(i, Valores.vectorVariables[1]);
                        arrayTabla.add((ArrayList<Character>) Valores.vectorVariables[1]);
                        break;
                    case 'R':
                        prop.set(i, Valores.vectorVariables[2]);
                        arrayTabla.add((ArrayList<Character>) Valores.vectorVariables[2]);
                        break;
                    case 'S':
                        prop.set(i, Valores.vectorVariables[3]);
                        arrayTabla.add((ArrayList<Character>) Valores.vectorVariables[3]);
                        break;
                    case 'T':
                        prop.set(i, Valores.vectorVariables[4]);
                        arrayTabla.add((ArrayList<Character>) Valores.vectorVariables[4]);
                        break;
                    case 'U':
                        prop.set(i, Valores.vectorVariables[5]);
                        arrayTabla.add((ArrayList<Character>) Valores.vectorVariables[5]);
                        break;
                }
            }
        }
        evaluacionTotal(prop);
//        System.out.println(prop);
//        System.out.println(arrayTabla.toString());
    }

    /**
    Método para evaluar en su totalidad la proposición
    @param prop
     */
    private static void evaluacionTotal(ArrayList<Object> prop) {
        for (int i = 0; i < prop.size(); i++) {
            if (prop.get(i).equals('y') || prop.get(i).equals('o') || prop.get(i).equals('f')
                    || prop.get(i).equals('b')) {
                char op = (char) prop.get(i);

                ArrayList<Character> x = (ArrayList<Character>) prop.get(i - 2);
//                System.out.println("X: " + x.toString());
                ArrayList<Character> y = (ArrayList<Character>) prop.get(i - 1);
//                System.out.println("Y: " + y.toString());
                ArrayList<Character> res = evaluacionOperador(op, x, y);
//                System.out.println("R: " + res.toString());

                arrayTabla.add(res);

                i = i - 2;
                prop.remove(i);
                prop.remove(i);
                prop.remove(i);
                prop.add(i, res);
//                System.out.println("Final: " + prop.toString() + "\n");
            } else if (prop.get(i).equals('-')) {
                char op = (char) prop.get(i);

                ArrayList<Character> x = (ArrayList<Character>) prop.get(i - 1);
//                System.out.println("X: " + x.toString());
                ArrayList<Character> res = evaluacionOperador(op, x, null);
//                System.out.println("R: " + res.toString());

                arrayTabla.add(res);

                i = i - 1;
                prop.remove(i);
                prop.remove(i);
                prop.add(i, res);
//                System.out.println("Final: " + prop.toString() + "\n");
            }
        }
    }

    /**
    Método para evaluar variables con operadores
    @param op
    @param x
    @param y
    @return 
     */
    private static ArrayList<Character> evaluacionOperador(char op, ArrayList<Character> x, ArrayList<Character> y) {
        ArrayList<Character> temp = new ArrayList<>();
        switch (op) {
            case '-':
                temp = Reglas.negacion(x);
                break;
            case 'y':
                temp = Reglas.conjuncion(x, y);
                break;
            case 'o':
                temp = Reglas.disyuncion(x, y);
                break;
            case 'f':
                temp = Reglas.condicionante(x, y);
                break;
            case 'b':
                temp = Reglas.bicondicionante(x, y);
                break;
        }
        return temp;
    }

    /**
    Método para evaluar si ArrayList final es tautología, falacia/contradicción o contingencia
    @return 
     */
    public static String evaluacionTipo() {
        ArrayList<Character> arr = arrayTabla.get(arrayTabla.size() - 1);

        int contadorV = 0;
        int contadorF = 0;

        for (int i = 0; i < arr.size(); i++) {
            if (arr.get(i) == 'V') {
                contadorV++;
            } else {
                contadorF++;
            }
        }
        if (contadorV == arr.size()) {
            return "Tautología";
        } else if (contadorF == arr.size()) {
            return "Falacia/contradicción";
        }
        return "Contingencia";
    }

//    public static String evaluacionTipo(ArrayList<Character> arr) {
//        int contadorV = 0;
//        int contadorF = 0;
//
//        for (int i = 0; i < arr.size(); i++) {
//            if (arr.get(i) == 'V') {
//                contadorV++;
//            } else {
//                contadorF++;
//            }
//        }
//        if (contadorV == arr.size()) {
//            return "Tautología";
//        } else if (contadorF == arr.size()) {
//            return "Falacia/contradicción";
//        }
//        return "Contingencia";
//    }
}
