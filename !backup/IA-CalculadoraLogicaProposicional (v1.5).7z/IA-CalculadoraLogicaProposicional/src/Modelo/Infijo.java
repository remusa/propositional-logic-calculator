/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

/**
 * 
 * @author rms
 */
public class Infijo {

    public static void main(String[] args) {
        test("((P→Q)^(P→R))→(P→R)", "P→Q^P→R→P→R");
        test("(P^Q)↔(-Qv-P)", "P^Q↔-Qv-P");
        test("((P→Q)^(Q^P))↔(P↔Q)", "P→Q^Q^P↔P↔Q");
    }

    public static String convertiraInfijo(String proposicion) {
        return proposicion.replaceAll("[( )]", "");
    }

    public static void test(String prueba, String esperado) {
        String res = convertiraInfijo(prueba);
        String evaluacion;

        if (res.equals(esperado)) {
            evaluacion = "true";
        } else {
            evaluacion = "false";
        }

        System.out.println("--------------------------------"
                + "\nPrueba: \t" + prueba
                + "\nResultado: \t" + res
                + "\nEsperado: \t" + esperado
                + "\nEvaluación: \t" + evaluacion
                + "\n--------------------------------\n");

    }
}
