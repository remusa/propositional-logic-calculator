/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.HashSet;

/**
 * 
 * @author rms
 */
public class Test {

    public static void main(String[] args) {
        System.out.println("No.: " + contarVariables("P^Q"));
    }

    private static int contarVariables(String proposicion) {
        String prop = proposicion.replaceAll("[^A-Za-z]", "");

        HashSet<Character> hash = new HashSet<>();
        prop = prop.toUpperCase();
        for (int i = 0; i < prop.length(); i++) {
            hash.add(prop.charAt(i));
        }
        return hash.size();
    }
}
