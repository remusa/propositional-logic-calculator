/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import Vista.VtnPrincipal;
import java.util.Stack;

/**
 * 
 * @author rms
 */
public class Prefijo {

    public static void main(String[] args) {
//        System.out.println(convertiraPostfijo("(P^Q)↔(-QvR)"));
//        System.out.println(convertiraPostfijo("(P^Q)↔(QvR)"));
//        System.out.println(convertiraPostfijo("(-P^(P→Q))↔(P→S)"));

        //∧ ∨ → ↔ ¬
        test("(P→Q^-R)↔((-P^-S)^R↔(P^-Q))^R→S", "P→Q^-R↔-P^-S^R↔P^-Q^R→S");
        test("((P→Q)^(P→R))→(P→R)", "P→Q^P→R→P→R");
        test("(P^Q)↔(-Qv-P)", "P^Q↔-Qv-P");
        test("((P→Q)^(Q^P))↔(P↔Q)", "P→Q^Q^P↔P↔Q");
    }

    /**
    Método para evaluar si un caracter recibido es un operador o no
    @param c
    @return 
     */
    private static boolean esOperador(char c) {
        return c == VtnPrincipal.CONJUNCION
                || c == VtnPrincipal.DISYUNCION
                || c == VtnPrincipal.CONDICIONAL
                || c == VtnPrincipal.BICONDICIONAL
                || c == VtnPrincipal.NEGACION
                || c == VtnPrincipal.PARENTESISABRE
                || c == VtnPrincipal.PARENTESISCIERRA;
    }

    /**
    Método para checar prioridad de operadores, los de menor prioridad son los
    primeros casos en checar
    @param op1
    @param op2
    @return 
     */
    private static boolean menorPrioridad(char op1, char op2) {
        switch (op1) {
            case '-':
                return op2 == '(';

            case '^':
            case 'v':
            case '→':
                return !(op2 == '^'
                        || op2 == 'v'
                        || op2 == '→');

            case '↔':
                return op2 == '(';

            case '(':
                return true;

            default:
                return false;

        }
    }

    /**
    Método para convertir en postfijo utilizando pilas
    @param proposicion
    @return 
     */
    public static String convertiraPrefijo(String proposicion) {
        proposicion = proposicion.replaceAll(" ", "");
        Stack<Character> pila = new Stack<>();
        StringBuilder postfijo = new StringBuilder(proposicion.length());
        char c;

        for (int i = 0; i < proposicion.length(); i++) {
            c = proposicion.charAt(i);

            if (!esOperador(c)) {
                postfijo.append(c);
            } else {
                if (c == VtnPrincipal.PARENTESISCIERRA) {
                    while (!pila.isEmpty() && pila.peek() != VtnPrincipal.PARENTESISABRE) {
                        postfijo.append(pila.pop());
                    }
                    if (!pila.isEmpty()) {
                        pila.pop();
                    }
                } else {
                    if (!pila.isEmpty() && !menorPrioridad(c, pila.peek())) {
                        pila.push(c);
                    } else {
                        while (!pila.isEmpty() && menorPrioridad(c, pila.peek())) {
                            Character pop = pila.pop();
                            if (c != VtnPrincipal.PARENTESISABRE) {
                                postfijo.append(pop);
                            } else {
                                c = pop;
                            }
                        }
                        pila.push(c);
                    }

                }
            }
        }
        while (!pila.isEmpty()) {
            postfijo.append(pila.pop());
        }
        String res = postfijo.toString();
        res = res.replaceAll("[( )]", "");
        return res;
    }

    public static void test(String prueba, String esperado) {
        String res = convertiraPrefijo(prueba);
        String evaluacion;

        if (res.equals(esperado)) {
            evaluacion = "true";
        } else {
            evaluacion = "false";
        }

        System.out.println("--------------------------------"
                + "\nPrueba: \t" + prueba
                + "\nResultado: \t" + res
                + "\nEsperado: \t" + esperado
                + "\nEvaluación: \t" + evaluacion
                + "\n--------------------------------\n");

    }

}
