/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author rms
 */
public class PostfijoTest {
    
    public PostfijoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }

    /**
     * Test of convertiraPostfijo method, of class Postfijo.
     */
    @Test
    public void testConvertiraPostfijo() {
        System.out.println("convertiraPostfijo");
        String proposicion = "(P∧Q)↔(¬Q∨R)";
        String expResult = "PQ∧Q¬R∨↔";
        String result = Postfijo.convertiraPostfijo(proposicion);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("Error al convertir en postfijo");
    }
    
    /**
     * Test 2
     */
    @Test
    public void testConvertiraPostfijo2() {
        System.out.println("convertiraPostfijo");
        String proposicion = "(P∧Q)↔(Q∨R)";
        String expResult = "PQ∧Q∨R↔";
        String result = Postfijo.convertiraPostfijo(proposicion);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("Error al convertir en postfijo");
    }
    
}
