/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Test;

//import static Modelo.Evaluacion.evaluacionOperador;
//import static Modelo.Postfijo.convertiraPostfijo;
//import java.util.ArrayList;

/**
 * 
 * @author rms
 */
public class Test {

//    public static void main(String[] args) {
//        ArrayList<Character> x = new ArrayList<>();
//        x.add('V');
//        x.add('V');
//        x.add('F');
//        x.add('F');
//
//        ArrayList<Character> y = new ArrayList<>();
//        y.add('V');
//        y.add('F');
//        y.add('V');
//        y.add('F');
//
//        testParteProposicion("PQy", x, y);
//        testEvaluacion(x, y);
//    }
//
//    public static Object[] testParteProposicion(String postfijo, ArrayList<Character> x, ArrayList<Character> y) {
//        Object[] res = new Object[2];
//        String exp = postfijo;
//        char op = exp.charAt(exp.length() - 1);
//        res[0] = exp;
//        res[1] = evaluacionOperador(op, x, y);
//        System.out.println("Proposición: " + res[0] + "\nEvaluación: " + res[1]);
//        return res;        
//    }
//
//    public static void testEvaluacion(ArrayList<Character> x, ArrayList<Character> y) {
//        System.out.println("X: " + x);
//        System.out.println("Y: " + y);
//        System.out.println("Negación: " + evaluacionOperador('-', x, y));
//        System.out.println("Conyunción: " + evaluacionOperador('y', x, y));
//        System.out.println("Disyunción: " + evaluacionOperador('o', x, y));
//        System.out.println("Condicionante: " + evaluacionOperador('f', x, y));
//        System.out.println("Bicondicionante: " + evaluacionOperador('b', x, y));
//    }

}
