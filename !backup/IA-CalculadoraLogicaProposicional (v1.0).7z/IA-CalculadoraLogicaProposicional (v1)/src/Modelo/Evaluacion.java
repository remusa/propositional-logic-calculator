/*
    1. Separar proposicion por postfijo
    2. Evaluar
    a. Caso 1: primeras 2 variables y primer operador, agregar resultado a arrFinal
    b. Caso 2: resultado de la primera evaluación, siguiente variable y siguiente operador, agregar resultado
        a arrFinal
 */
package Modelo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;

/**
 *
 * @author rms
 */
public class Evaluacion extends Arreglos {

    private static final Stack pila = new Stack();
    private static ArrayList<Character> separadores = new ArrayList<>();
    private static ArrayList<Character> res = new ArrayList<>();
    private static ArrayList<Object[]> arrFinal = new ArrayList<>();

//    private static final String[] separadores = {"y", "o", "f", "b", "-"};
    public static void main(String[] args) {
        separadores.add('y');
        separadores.add('o');
        separadores.add('f');
        separadores.add('b');
        separadores.add('-');

        String proposicion = "PQyRoSfTb"; //en postfijo
        evaluacionTotal(proposicion);
    }

    /**
    Método para evaluar en su totalidad la proposición
    @param proposicion
    @return 
     */
    public static ArrayList<Object[]> evaluacionTotal(String proposicion) {
        String prop = proposicion;
        prop = prop.replaceAll("y", "y ");
        prop = prop.replaceAll("o", "o ");
        prop = prop.replaceAll("f", "f ");
        prop = prop.replaceAll("b", "b ");
        prop = prop.replaceAll("-", "- ");
        String[] prop2 = prop.split(" ");
        System.out.println(Arrays.toString(prop2));
        
        for (int i = 0; i < prop2.length; i++) {
            for (int j = 0; j < prop2[i].length(); j++) {
                if (!separadores.contains(prop2[i].charAt(j))) {
                    pila.add(prop2[i].charAt(j));
                } else {
                    
                }
            }
        }
        
        do {
            System.out.println(pila.pop());
        } while (!pila.isEmpty());


//        for (int i = 0; i < prop2.length; i++) {
//            ArrayList<Character> x = new ArrayList<>();
//            ArrayList<Character> y = new ArrayList<>();
//            ArrayList<Character> resultado = new ArrayList<>();
//            char op = ' ';
//            if ((prop2[i].charAt(2) == 'y')) {
//                op = 'y';
//                
//            } 
//            else if ((prop2[i].charAt(1) == 'o' || prop2[i].charAt(2) == 'o')) {
//                op = 'o';
//            } else if ((prop2[i].charAt(1) == 'f' || prop2[i].charAt(2) == 'f')) {
//                op = 'f';
//            } else if ((prop2[i].charAt(1) == 'b' || prop2[i].charAt(2) == 'b')) {
//                op = 'b';
//            } else if ((prop2[i].charAt(1) == '-')) {
//                op = '-';
//            }
//        }

        return arrFinal;
    }

    /**
    Método para evaluar una parte de la proposición
    @param postfijo
    @param x
    @param y
    @return 
     */
    public static Object[] evaluacionParte(String postfijo, ArrayList<Character> x, ArrayList<Character> y) {
        Object[] parte = new Object[2];
        String exp = postfijo;
        char op = exp.charAt(exp.length() - 1);
        parte[0] = exp;
        parte[1] = evaluacionOperador(op, x, y);
        System.out.println("Proposición: " + parte[0] + "\nEvaluación: " + parte[1]);
        return parte;
    }

    /**
    Método para evaluar proposiciones
    @param op
    @param x
    @param y
    @return 
     */
    public static ArrayList<Character> evaluacionOperador(Character op, ArrayList<Character> x, ArrayList<Character> y) {
        res.clear();
        switch (op) {
            case '-':
                res = Reglas.negacion(x);
                break;
            case 'y':
                res = Reglas.conjuncion(x, y);
                break;
            case 'o':
                res = Reglas.disyuncion(x, y);
                break;
            case 'f':
                res = Reglas.condicionante(x, y);
                break;
            case 'b':
                res = Reglas.bicondicionante(x, y);
                break;
        }
        return res;
    }

    /**
    Método para evaluar si ArrayList final es tautología, falacia/contradicción o contingencia
    @param arr
    @return 
     */
    public static String evaluacionTipo(ArrayList<Character> arr) {
        int contadorV = 0;
        int contadorF = 0;

        for (int i = 0; i < arr.size(); i++) {
            if (arr.get(i) == 'V') {
                contadorV++;
            } else {
                contadorF++;
            }
        }
        if (contadorV == arr.size()) {
            return "Tautología";
        } else if (contadorF == arr.size()) {
            return "Falacia/contradicción";
        }
        return "Contingencia";
    }

}
