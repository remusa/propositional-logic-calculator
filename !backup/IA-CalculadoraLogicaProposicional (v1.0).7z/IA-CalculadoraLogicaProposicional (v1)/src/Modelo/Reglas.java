/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Modelo;

import java.util.ArrayList;

/**
 * 
 * @author rms
 */
public class Reglas {

    private static final ArrayList<Character> res = new ArrayList<>();

    /**
    Método para negar cada valor recibido en un ArrayList
    @param x
    @return 
     */
    public static ArrayList<Character> negacion(ArrayList<Character> x) {
        res.clear();
        for (int i = 0; i < x.size(); i++) {
            if (x.get(i) == 'V') {
                res.add('F');
            } else if (x.get(i) == 'F') {
                res.add('V');
            }
        }
        return res;
    }

    /**
    Método para evaluar la conjunción
    @param x
    @param y
    @return 
     */
    public static ArrayList<Character> conjuncion(ArrayList<Character> x, ArrayList<Character> y) {
        res.clear();
        for (int i = 0; i < x.size(); i++) {
            if (x.get(i) == 'V' && y.get(i) == 'V') {
                res.add('V');
            } else {
                res.add('F');
            }
        }
        return res;
    }

    /**
    Método para evaluar la disyunción
    @param x
    @param y
    @return 
     */
    public static ArrayList<Character> disyuncion(ArrayList<Character> x, ArrayList<Character> y) {
        res.clear();
        for (int i = 0; i < x.size(); i++) {
            if (x.get(i) == 'F' && y.get(i) == 'F') {
                res.add('F');
            } else {
                res.add('V');
            }
        }
        return res;
    }

    /**
    Método para evaluar la condicionante
    @param x
    @param y
    @return 
     */
    public static ArrayList<Character> condicionante(ArrayList<Character> x, ArrayList<Character> y) {
        res.clear();
        for (int i = 0; i < x.size(); i++) {
            if (x.get(i) == 'V' && y.get(i) == 'F') {
                res.add('F');
            } else {
                res.add('V');
            }
        }
        return res;
    }

    /**
    Método para evaluar la bicondicionante
    @param x
    @param y
    @return 
     */
    public static ArrayList<Character> bicondicionante(ArrayList<Character> x, ArrayList<Character> y) {
        res.clear();
        for (int i = 0; i < x.size(); i++) {
            if ((x.get(i) == 'V' && y.get(i) == 'V')
                    || (x.get(i) == 'F' && y.get(i) == 'F')) {
                res.add('V');
            } else {
                res.add('F');
            }
        }
        return res;
    }

}
